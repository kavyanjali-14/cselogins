const app = require("./index");


app.listen(3000, () => {
    console.log("SERVER RUNNING SUSSESSFULLY");
} );