const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const session = require("express-session");

const app = express();

// ---------------- MIDDLEWARE ----------------
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(session({
  secret: "secretkey",
  resave: false,
  saveUninitialized: true
}));

// ---------------- DATABASE ----------------
mongoose.connect("mongodb://localhost:27017/devopscse")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

// ---------------- USER SCHEMA ----------------
const userSchema = new mongoose.Schema(
  {
    username: String,
    password: String
  },
  {
    versionKey: false   // 👈 THIS REMOVES __v
  }
);

const User = mongoose.model("User", userSchema);


// ---------------- ROUTES ----------------

// Home
app.get("/", (req, res) => {
  res.send(`
    <h2>Home</h2>
    <a href="/register">Register</a><br><br>
    <a href="/login">Login</a>
  `);
});

// -------- REGISTER PAGE --------
app.get("/register", (req, res) => {
  res.send(`
    <h2>Register</h2>
    <form method="POST" action="/register">
      <input type="text" name="username" placeholder="Username" required /><br><br>
      <input type="password" name="password" placeholder="Password" required /><br><br>
      <button type="submit">Register</button>
    </form>
    <br>
    <a href="/login">Go to Login</a>
  `);
});

// -------- REGISTER LOGIC --------
app.post("/register", async (req, res) => {
  const { username, password } = req.body;

  const hashedPassword = await bcrypt.hash(password, 10);

  const user = new User({
    username,
    password: hashedPassword
  });

  await user.save();
  res.send("Registration Successful <br><a href='/login'>Login Now</a>");
});

// -------- LOGIN PAGE --------
app.get("/login", (req, res) => {
  res.send(`
    <h2>Login</h2>
    <form method="POST" action="/login">
      <input type="text" name="username" placeholder="Username" required /><br><br>
      <input type="password" name="password" placeholder="Password" required /><br><br>
      <button type="submit">Login</button>
    </form>
  `);
});

// -------- LOGIN LOGIC --------
app.post("/login", async (req, res) => {
  const { username, password } = req.body;

  const user = await User.findOne({ username });
  if (!user) {
    return res.send("User not found");
  }

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    return res.send("Invalid Password");
  }

  req.session.user = user;
  res.redirect("/dashboard");
});

// -------- DASHBOARD --------
app.get("/dashboard", (req, res) => {
  if (!req.session.user) {
    return res.send("Please login first");
  }

  res.send(`
    <h2>Welcome ${req.session.user.username}</h2>
    <p>You are logged in</p>
    <a href="/logout">Logout</a>
  `);
});

// -------- LOGOUT --------
app.get("/logout", (req, res) => {
  req.session.destroy();
  res.send("Logged out successfully <br><a href='/login'>Login again</a>");
});

// ---------------- SERVER ----------------
app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
